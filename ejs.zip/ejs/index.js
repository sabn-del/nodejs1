
var express= require('express');
var app=express();

var booksRouter=require('./src/router/bookrouter');
var authorrouter=require('./src/router/authorrouter');

app.use(express.static('./public'));
app.use('/book',booksRouter);
app.use('/sinauthor',authorrouter);



app.set('view engine','ejs');
app.set('views','./src/views');
app.get('/',(req,res)=>{
    //res.render('index');
    //res.render('index',{book:['book1,book2'],title:'library'})
    res.render('index',{nav:[{link:'/',name:'home'},{link:'/',name:'about'},{link:'/book',name:'book'},{link:'/',name:'Sign in'}]})
});





 


app.listen(8080,function(){
 console.log('the server is start');
})
