var express= require('express');
const booksRouter=express.Router();

var books=[
    {
    bname:"My Best wife",
    author:"Ajay pandey",
    image:"images.jpg"
    },
    {
        bname:"wings Of fire",
        author:"A.p.j abdhulKalam",
        image:"images.jpg"
        },
        {
            bname:"wings Of fire",
            author:"A.p.j abdhulKalam",
            image:"images.jpg"
            },
        {
            bname:"My Story",
            author:"madhavikutty",
            image:"images.jpg"
            }

];
booksRouter.get('/',(req,res)=>{
    res.render('book',{nav:[{link:'/',name:'home'},{link:'/',name:'about'},{link:'/author',name:'author'},{link:'/',name:'Sign in'}],books})
});
booksRouter.get('/:id',(req,res)=>{
    const id= req.params.id;
    res.render('readmore',{nav:[{link:'/',name:'home'},{link:'/',name:'about'},{link:'/',name:'contact'},{link:'/',name:'Sign in'}],book:books[id]})
});
module.exports=booksRouter;